<!-- Generated file — do not edit; regenerated with the SDK. -->

# Client — operations

Accessor: `client` · Source: `sway_api/client.py` · 10 operations

Each `###` block is one operation and assumes `sdk-map.md` is loaded: blocks omit what its invariants table covers and are otherwise self-contained, so chunk at block level. Signatures are the sync parsed spelling; the async and raw spellings take the same parameters (see sdk-map.md). **Type sources** names the module declaring each type an operation mentions, so resolving a body, return or error payload is a lookup rather than a search; the runtime types `RawError` and `ApiResult` are excluded, and an operation with no table mentions nothing but builtins and those.

### client.get_evidence

- **Route**: `GET /api/evidence`
- **Signature**: `def get_evidence(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `Evidence`
- **Returns (raw)**: `ApiResult[Evidence, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `Evidence` | `sway_api/models/evidence.py` |

### client.get_health

- **Route**: `GET /api/health`
- **Signature**: `def get_health(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `Health`
- **Returns (raw)**: `ApiResult[Health, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `Health` | `sway_api/models/health.py` |

### client.get_results

- **Route**: `GET /api/results`
- **Signature**: `def get_results(*, run: str | None = None, request_options: RequestOptionsOrDict | None = None)`
- **Params**: `run` — query
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, RawError]`
- **Error**: `RawError` — **Case B**

### client.get_tasks

- **Route**: `GET /api/tasks`
- **Signature**: `def get_tasks(*, request_options: RequestOptionsOrDict | None = None)`
- **Returns (parsed)**: `TasksEnvelope`
- **Returns (raw)**: `ApiResult[TasksEnvelope, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `TasksEnvelope` | `sway_api/models/tasks_envelope.py` |

### client.post_payouts_credit

- **Route**: `POST /api/payouts/credit`
- **Signature**: `def post_payouts_credit(body: ApiPayoutsCreditRequest | ApiPayoutsCreditRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiPayoutsCreditRequest` | `sway_api/models/api_payouts_credit_request.py` |
| `ApiPayoutsCreditRequestDict` | `sway_api/models/api_payouts_credit_request.py` |

### client.post_pick

- **Route**: `POST /api/pick`
- **Signature**: `def post_pick(body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Pick`
- **Returns (raw)**: `ApiResult[Pick, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `TaskConditionBody` | `sway_api/models/task_condition_body.py` |
| `TaskConditionBodyDict` | `sway_api/models/task_condition_body.py` |
| `Pick` | `sway_api/models/pick.py` |

### client.post_publishers_onboard

- **Route**: `POST /api/publishers/onboard`
- **Signature**: `def post_publishers_onboard(body: ApiPublishersOnboardRequest | ApiPublishersOnboardRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiPublishersOnboardRequest` | `sway_api/models/api_publishers_onboard_request.py` |
| `ApiPublishersOnboardRequestDict` | `sway_api/models/api_publishers_onboard_request.py` |

### client.post_vault_test

- **Route**: `POST /api/vault/test`
- **Signature**: `def post_vault_test(body: ApiVaultTestRequest | ApiVaultTestRequestDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `ApiVaultTestRequest` | `sway_api/models/api_vault_test_request.py` |
| `ApiVaultTestRequestDict` | `sway_api/models/api_vault_test_request.py` |

### client.post_verdict

- **Route**: `POST /api/verdict`
- **Signature**: `def post_verdict(body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Verdict`
- **Returns (raw)**: `ApiResult[Verdict, RawError]`
- **Error**: `RawError` — **Case B**

| Type | Source |
| --- | --- |
| `TaskConditionBody` | `sway_api/models/task_condition_body.py` |
| `TaskConditionBodyDict` | `sway_api/models/task_condition_body.py` |
| `Verdict` | `sway_api/models/verdict.py` |

### client.post_webhooks_paypal

- **Route**: `POST /api/webhooks/paypal`
- **Signature**: `def post_webhooks_paypal(body: Any, *, request_options: RequestOptionsOrDict | None = None)`
  - required, positional: `body`
- **Params**: `body` — JSON body
- **Returns (parsed)**: `Any`
- **Returns (raw)**: `ApiResult[Any, PostWebhooksPaypalErrorBody]`
- **Error**: `PostWebhooksPaypalErrorBody` — **Case A (typed)**
- **Error arms**: `RawError` [401, anything unmapped]

| Type | Source |
| --- | --- |
| `PostWebhooksPaypalErrorBody` | `sway_api/errors/post_webhooks_paypal_error.py` |

