from __future__ import annotations

from typing import Any

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Evidence(SdkBaseModel):
    main_run: Optional[str] = UNSET
    main: Optional[list[Any]] = UNSET
    subtle: Optional[list[Any]] = UNSET
    model: Optional[str] = UNSET
    k: Optional[int] = UNSET


class EvidenceDict(TypedDict):
    main_run: NotRequired[str]
    main: NotRequired[list[Any]]
    subtle: NotRequired[list[Any]]
    model: NotRequired[str]
    k: NotRequired[int]
