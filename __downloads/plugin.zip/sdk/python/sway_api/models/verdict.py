from __future__ import annotations

from typing import Any

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel
from .enums.verdict1 import Verdict1OrStr


class Verdict(SdkBaseModel):
    verdict: Optional[Verdict1OrStr] = UNSET
    sentence: Optional[str] = UNSET
    chosen: Optional[str] = UNSET
    stability: Optional[float] = UNSET
    xray: Optional[list[Any]] = UNSET
    decider: OptionalNullable[str] = UNSET
    payout_eligible: Optional[bool] = UNSET


class VerdictDict(TypedDict):
    verdict: NotRequired[Verdict1OrStr]
    sentence: NotRequired[str]
    chosen: NotRequired[str]
    stability: NotRequired[float]
    xray: NotRequired[list[Any]]
    decider: NotRequired[str | None]
    payout_eligible: NotRequired[bool]
