from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Health(SdkBaseModel):
    ok: bool
    backend: Optional[str] = UNSET
    model: Optional[str] = UNSET
    k: Optional[int] = UNSET


class HealthDict(TypedDict):
    ok: bool
    backend: NotRequired[str]
    model: NotRequired[str]
    k: NotRequired[int]
