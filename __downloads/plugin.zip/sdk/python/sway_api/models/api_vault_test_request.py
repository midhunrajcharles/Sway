from __future__ import annotations

from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiVaultTestRequest(SdkBaseModel):
    vault_id: str = Field(alias="vaultId")
    amount: Optional[float] = UNSET


class ApiVaultTestRequestDict(TypedDict):
    vault_id: str
    amount: NotRequired[float]
