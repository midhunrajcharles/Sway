from __future__ import annotations

from pydantic import EmailStr, Field
from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class ApiPublishersOnboardRequest(SdkBaseModel):
    host: str
    publisher_email: Optional[EmailStr] = Field(default=UNSET, alias="publisherEmail")
    return_url: Optional[str] = Field(default=UNSET, alias="returnUrl")


class ApiPublishersOnboardRequestDict(TypedDict):
    host: str
    publisher_email: NotRequired[EmailStr]
    return_url: NotRequired[str]
