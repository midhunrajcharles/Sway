from __future__ import annotations

from typing_extensions import TypedDict

from ..core import SdkBaseModel
from .enums.condition import ConditionOrStr


class TaskConditionBody(SdkBaseModel):
    task: str
    condition: ConditionOrStr


class TaskConditionBodyDict(TypedDict):
    task: str
    condition: ConditionOrStr
