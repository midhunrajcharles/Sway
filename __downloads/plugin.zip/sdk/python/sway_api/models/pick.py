from __future__ import annotations

from typing import Any

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, OptionalNullable, SdkBaseModel
from .page import Page, PageDict
from .product import Product, ProductDict


class Pick(SdkBaseModel):
    task: Optional[Any] = UNSET
    products: Optional[list[Product]] = UNSET
    condition: Optional[str] = UNSET
    chosen: Optional[str] = UNSET
    stability: Optional[float] = UNSET
    pages: Optional[list[Page]] = UNSET
    target: OptionalNullable[str] = UNSET


class PickDict(TypedDict):
    task: NotRequired[Any]
    products: NotRequired[list[ProductDict]]
    condition: NotRequired[str]
    chosen: NotRequired[str]
    stability: NotRequired[float]
    pages: NotRequired[list[PageDict]]
    target: NotRequired[str | None]
