from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from ..core import SdkBaseModel


class ApiPayoutsCreditRequest(SdkBaseModel):
    order_id: str = Field(alias="orderId")


class ApiPayoutsCreditRequestDict(TypedDict):
    order_id: str
