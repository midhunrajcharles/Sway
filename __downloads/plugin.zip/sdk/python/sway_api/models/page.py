from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Page(SdkBaseModel):
    id: Optional[str] = UNSET
    url: Optional[str] = UNSET


class PageDict(TypedDict):
    id: NotRequired[str]
    url: NotRequired[str]
