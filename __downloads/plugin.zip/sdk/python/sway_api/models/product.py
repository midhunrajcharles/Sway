from __future__ import annotations

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class Product(SdkBaseModel):
    id: Optional[str] = UNSET
    name: Optional[str] = UNSET
    price: Optional[float] = UNSET
    seller: Optional[str] = UNSET


class ProductDict(TypedDict):
    id: NotRequired[str]
    name: NotRequired[str]
    price: NotRequired[float]
    seller: NotRequired[str]
