from .condition import Condition, ConditionOrStr
from .verdict1 import Verdict1, Verdict1OrStr

__all__ = ["Condition", "ConditionOrStr", "Verdict1", "Verdict1OrStr"]
