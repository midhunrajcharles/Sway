from enum import Enum
from typing import Annotated, TypeAlias

from ...core import open_enum_validator


class Condition(str, Enum):
    CLEAN = "clean"
    HONEST_STRONG = "honest_strong"
    ATTACK_HIDDEN = "attack_hidden"
    ATTACK_REDUNDANT = "attack_redundant"
    DECEPTIVE_VISIBLE = "deceptive_visible"
    COVERT_INSTRUCTION = "covert_instruction"
    PRICE_SMEAR = "price_smear"
    FAKE_REVIEWS = "fake_reviews"

    __str__ = str.__str__


ConditionOrStr: TypeAlias = Annotated[Condition | str, open_enum_validator(Condition)]
