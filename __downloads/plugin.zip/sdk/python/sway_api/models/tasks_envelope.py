from __future__ import annotations

from typing import Any

from typing_extensions import NotRequired, TypedDict

from ..core import UNSET, Optional, SdkBaseModel


class TasksEnvelope(SdkBaseModel):
    conditions: Optional[list[str]] = UNSET
    tasks: Optional[list[Any]] = UNSET


class TasksEnvelopeDict(TypedDict):
    conditions: NotRequired[list[str]]
    tasks: NotRequired[list[Any]]
