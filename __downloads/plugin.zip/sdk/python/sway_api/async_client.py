from __future__ import annotations

from functools import cached_property
from types import TracebackType
from typing import Any
from uuid import UUID, uuid4

from typing_extensions import Self

from .base_client import DEFAULT_TIMEOUT, BaseSwayApiClient
from .core import (
    OPERATING_SYSTEM,
    PYTHON_RUNTIME,
    ApiResult,
    AsyncHttpClient,
    AsyncHttpx2Client,
    AsyncRawClient,
    BaseRawResponse,
    LoggingOptionsOrDict,
    RawError,
    RequestOptionsOrDict,
    RetryOptionsOrDict,
    async_json_decoder,
    json_body,
    param,
    raw_error_response,
    unwrap,
)
from .errors.post_webhooks_paypal_error import PostWebhooksPaypalErrorBody, post_webhooks_paypal_error_mapper
from .models.api_payouts_credit_request import ApiPayoutsCreditRequest, ApiPayoutsCreditRequestDict
from .models.api_publishers_onboard_request import ApiPublishersOnboardRequest, ApiPublishersOnboardRequestDict
from .models.api_vault_test_request import ApiVaultTestRequest, ApiVaultTestRequestDict
from .models.evidence import Evidence
from .models.health import Health
from .models.pick import Pick
from .models.task_condition_body import TaskConditionBody, TaskConditionBodyDict
from .models.tasks_envelope import TasksEnvelope
from .models.verdict import Verdict
from .server.environment import Environment
from .server.server import Server


class AsyncSwayApiClient(BaseSwayApiClient[AsyncRawClient]):
    def __init__(
        self,
        *,
        environment: Environment = "production",
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        retry_options: int | RetryOptionsOrDict | None = None,
        logging_options: LoggingOptionsOrDict | None = None,
        custom_async_http_client: AsyncHttpClient | None = None,
    ) -> None:
        super().__init__(
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            retry_options=retry_options,
            logging_options=logging_options,
        )
        self._raw_client = AsyncRawClient(
            http_client=(
                custom_async_http_client if custom_async_http_client is not None else AsyncHttpx2Client(timeout=timeout)
            ),
            retry_options=self._retry_options,
            logging_options=self._logging_options,
            global_headers=[
                param[str]("User-Agent", "SwayApiClient/0.2.0 Python"),
                param[str]("X-APIMatic-Lang", "Python"),
                param[str]("X-APIMatic-Package-Version", "0.2.0"),
                param[str]("X-APIMatic-Gen-Version", "4.0.0"),
                param[str]("X-APIMatic-OS", OPERATING_SYSTEM),
                param[str]("X-APIMatic-Runtime", PYTHON_RUNTIME),
            ],
        )

    @cached_property
    def with_raw_response(self) -> AsyncApiWithRawResponse:
        return AsyncApiWithRawResponse(self._raw_client, self._server)

    async def get_evidence(self, *, request_options: RequestOptionsOrDict | None = None) -> Evidence:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            evidence payload

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.get_evidence(request_options=request_options))

    async def get_health(self, *, request_options: RequestOptionsOrDict | None = None) -> Health:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            ok

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.get_health(request_options=request_options))

    async def get_results(self, *, run: str | None = None, request_options: RequestOptionsOrDict | None = None) -> Any:
        """Send a ``GET`` request.

        Args:
            run: Specific results directory (defaults to the latest in results/).
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            results rows + xray

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.get_results(run=run, request_options=request_options))

    async def get_tasks(self, *, request_options: RequestOptionsOrDict | None = None) -> TasksEnvelope:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            tasks + conditions

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.get_tasks(request_options=request_options))

    async def post_payouts_credit(
        self,
        body: ApiPayoutsCreditRequest | ApiPayoutsCreditRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> Any:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            payout result

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.post_payouts_credit(body, request_options=request_options))

    async def post_pick(
        self, body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> Pick:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            agent pick + stability

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.post_pick(body, request_options=request_options))

    async def post_publishers_onboard(
        self,
        body: ApiPublishersOnboardRequest | ApiPublishersOnboardRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> Any:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            referral session

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.post_publishers_onboard(body, request_options=request_options))

    async def post_vault_test(
        self,
        body: ApiVaultTestRequest | ApiVaultTestRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> Any:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            probe result

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.post_vault_test(body, request_options=request_options))

    async def post_verdict(
        self, body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> Verdict:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            verdict + x-ray + one-sentence explanation

        Raises:
            ApiError: If the API responds with an error status code. ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.post_verdict(body, request_options=request_options))

    async def post_webhooks_paypal(self, body: Any, *, request_options: RequestOptionsOrDict | None = None) -> Any:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            received

        Raises:
            ApiError: signature verification failed ``error`` is ``RawError``."""
        return unwrap(await self.with_raw_response.post_webhooks_paypal(body, request_options=request_options))

    async def aclose(self) -> None:
        await self._raw_client.http_client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None
    ) -> None:
        await self.aclose()


class AsyncApiWithRawResponse(BaseRawResponse[AsyncRawClient, Server]):
    async def get_evidence(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Evidence, RawError]:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/evidence"),
            decoder=async_json_decoder[Evidence],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def get_health(self, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Health, RawError]:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/health"),
            decoder=async_json_decoder[Health],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def get_results(
        self, *, run: str | None = None, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Any, RawError]:
        """Send a ``GET`` request.

        Args:
            run: Specific results directory (defaults to the latest in results/).
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/results"),
            query_params=[param[str | None]("run", run)],
            decoder=async_json_decoder[Any],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def get_tasks(
        self, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[TasksEnvelope, RawError]:
        """Send a ``GET`` request.

        Args:
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="GET",
            url_template=self._server.default("/api/tasks"),
            decoder=async_json_decoder[TasksEnvelope],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def post_payouts_credit(
        self,
        body: ApiPayoutsCreditRequest | ApiPayoutsCreditRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[Any, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/payouts/credit"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiPayoutsCreditRequest | ApiPayoutsCreditRequestDict](body),
            decoder=async_json_decoder[Any],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def post_pick(
        self, body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Pick, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/pick"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[TaskConditionBody | TaskConditionBodyDict](body),
            decoder=async_json_decoder[Pick],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def post_publishers_onboard(
        self,
        body: ApiPublishersOnboardRequest | ApiPublishersOnboardRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[Any, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/publishers/onboard"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiPublishersOnboardRequest | ApiPublishersOnboardRequestDict](body),
            decoder=async_json_decoder[Any],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def post_vault_test(
        self,
        body: ApiVaultTestRequest | ApiVaultTestRequestDict,
        *,
        request_options: RequestOptionsOrDict | None = None,
    ) -> ApiResult[Any, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/vault/test"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[ApiVaultTestRequest | ApiVaultTestRequestDict](body),
            decoder=async_json_decoder[Any],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def post_verdict(
        self, body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Verdict, RawError]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/verdict"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[TaskConditionBody | TaskConditionBodyDict](body),
            decoder=async_json_decoder[Verdict],
            error_mapper=raw_error_response,
            request_options=request_options,
        )

    async def post_webhooks_paypal(
        self, body: Any, *, request_options: RequestOptionsOrDict | None = None
    ) -> ApiResult[Any, PostWebhooksPaypalErrorBody]:
        """Send a ``POST`` request.

        Args:
            body: The request body.
            request_options: Per-call overrides for this one request, such as a timeout, extra headers, or its retry
                count and statuses.

        Returns:
            An ``ApiResult`` holding the deserialized response or the error body."""
        return await self._client.execute(
            http_method="POST",
            url_template=self._server.default("/api/webhooks/paypal"),
            headers=[param[UUID]("Idempotency-Key", uuid4())],
            body=json_body[Any](body),
            decoder=async_json_decoder[Any],
            error_mapper=post_webhooks_paypal_error_mapper,
            request_options=request_options,
        )


AsyncClient = AsyncSwayApiClient
