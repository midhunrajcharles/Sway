from .post_webhooks_paypal_error import PostWebhooksPaypalErrorBody, post_webhooks_paypal_error_mapper

__all__ = ["PostWebhooksPaypalErrorBody", "post_webhooks_paypal_error_mapper"]
