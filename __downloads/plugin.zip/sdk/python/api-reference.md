# Reference

**Parsed** endpoints return the typed payload and raise `ApiError` on a documented non-2xx. For the raw endpoints, see [Raw API Reference](raw-api-reference.md).

> Source: [SwayApiClient](sway_api/client.py)

<details>
<summary><code>def get_evidence(*, request_options: RequestOptionsOrDict | None = None) -> Evidence</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.get_evidence()
    # TODO: Handle 'response' of type Evidence
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.get_evidence()
    # TODO: Handle 'response' of type Evidence
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Evidence](sway_api/models/evidence.py)</code> -- evidence payload

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_health(*, request_options: RequestOptionsOrDict | None = None) -> Health</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.get_health()
    # TODO: Handle 'response' of type Health
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.get_health()
    # TODO: Handle 'response' of type Health
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Health](sway_api/models/health.py)</code> -- ok

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_results(*, run: str | None = None, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.get_results()
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.get_results()
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>run</code> | <code>str \| None</code> | Specific results directory (defaults to the latest in results/).<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- results rows + xray

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_tasks(*, request_options: RequestOptionsOrDict | None = None) -> TasksEnvelope</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.get_tasks()
    # TODO: Handle 'response' of type TasksEnvelope
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.get_tasks()
    # TODO: Handle 'response' of type TasksEnvelope
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[TasksEnvelope](sway_api/models/tasks_envelope.py)</code> -- tasks + conditions

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_payouts_credit(body: ApiPayoutsCreditRequest | ApiPayoutsCreditRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.post_payouts_credit(ApiPayoutsCreditRequest(order_id="some example string"))
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.post_payouts_credit(ApiPayoutsCreditRequest(order_id="some example string"))
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPayoutsCreditRequest](sway_api/models/api_payouts_credit_request.py) \| [ApiPayoutsCreditRequestDict](sway_api/models/api_payouts_credit_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- payout result

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_pick(body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None) -> Pick</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.post_pick(TaskConditionBody(task="some example string", condition=Condition.CLEAN))
    # TODO: Handle 'response' of type Pick
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.post_pick(TaskConditionBody(task="some example string", condition=Condition.CLEAN))
    # TODO: Handle 'response' of type Pick
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[TaskConditionBody](sway_api/models/task_condition_body.py) \| [TaskConditionBodyDict](sway_api/models/task_condition_body.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Pick](sway_api/models/pick.py)</code> -- agent pick + stability

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_publishers_onboard(body: ApiPublishersOnboardRequest | ApiPublishersOnboardRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.post_publishers_onboard(ApiPublishersOnboardRequest(host="some example string"))
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.post_publishers_onboard(ApiPublishersOnboardRequest(host="some example string"))
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPublishersOnboardRequest](sway_api/models/api_publishers_onboard_request.py) \| [ApiPublishersOnboardRequestDict](sway_api/models/api_publishers_onboard_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- referral session

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_vault_test(body: ApiVaultTestRequest | ApiVaultTestRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.post_vault_test(ApiVaultTestRequest(vault_id="some example string"))
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.post_vault_test(ApiVaultTestRequest(vault_id="some example string"))
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiVaultTestRequest](sway_api/models/api_vault_test_request.py) \| [ApiVaultTestRequestDict](sway_api/models/api_vault_test_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- probe result

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_verdict(body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None) -> Verdict</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.post_verdict(TaskConditionBody(task="some example string", condition=Condition.CLEAN))
    # TODO: Handle 'response' of type Verdict
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

**Async**

```python
try:
    response = await async_client.post_verdict(TaskConditionBody(task="some example string", condition=Condition.CLEAN))
    # TODO: Handle 'response' of type Verdict
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[TaskConditionBody](sway_api/models/task_condition_body.py) \| [TaskConditionBodyDict](sway_api/models/task_condition_body.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Verdict](sway_api/models/verdict.py)</code> -- verdict + x-ray + one-sentence explanation

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[RawError](sway_api/core/results.py)&#93;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_webhooks_paypal(body: Any, *, request_options: RequestOptionsOrDict | None = None) -> Any</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
try:
    response = client.post_webhooks_paypal({})
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type PostWebhooksPaypalErrorBody
```

**Async**

```python
try:
    response = await async_client.post_webhooks_paypal({})
    # TODO: Handle 'response' of type Any
except ApiError as e:
    ...  # TODO: Handle 'e.error' of type PostWebhooksPaypalErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>Any</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>Any</code> -- received

**OnError**: <code>[ApiError](sway_api/core/exceptions.py)&#91;[PostWebhooksPaypalErrorBody](sway_api/errors/post_webhooks_paypal_error.py)&#93;</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 401 | <code>[RawError](sway_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](sway_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

