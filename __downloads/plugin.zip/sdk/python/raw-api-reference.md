# Raw Reference

**Raw** endpoints, reached through `with_raw_response`, return `ApiResult[T, E]` and never raise for an API error. For the parsed endpoints, see [API Reference](api-reference.md).

> Source: [SwayApiClient](sway_api/client.py)

<details>
<summary><code>def get_evidence(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Evidence, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.get_evidence()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Evidence
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.get_evidence()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Evidence
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;[Evidence](sway_api/models/evidence.py), [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[Evidence](sway_api/models/evidence.py)</code> -- evidence payload

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_health(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Health, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.get_health()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Health
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.get_health()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Health
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;[Health](sway_api/models/health.py), [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[Health](sway_api/models/health.py)</code> -- ok

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_results(*, run: str | None = None, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Any, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.get_results()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.get_results()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>run</code> | <code>str \| None</code> | Specific results directory (defaults to the latest in results/).<br>**Default**: <code>None</code> |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;Any, [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>Any</code> -- results rows + xray

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def get_tasks(*, request_options: RequestOptionsOrDict | None = None) -> ApiResult[TasksEnvelope, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `GET` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.get_tasks()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type TasksEnvelope
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.get_tasks()
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type TasksEnvelope
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;[TasksEnvelope](sway_api/models/tasks_envelope.py), [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[TasksEnvelope](sway_api/models/tasks_envelope.py)</code> -- tasks + conditions

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_payouts_credit(body: ApiPayoutsCreditRequest | ApiPayoutsCreditRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Any, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.post_payouts_credit(ApiPayoutsCreditRequest(order_id="some example string"))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.post_payouts_credit(
    ApiPayoutsCreditRequest(order_id="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPayoutsCreditRequest](sway_api/models/api_payouts_credit_request.py) \| [ApiPayoutsCreditRequestDict](sway_api/models/api_payouts_credit_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;Any, [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>Any</code> -- payout result

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_pick(body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Pick, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.post_pick(TaskConditionBody(task="some example string", condition=Condition.CLEAN))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Pick
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.post_pick(
    TaskConditionBody(task="some example string", condition=Condition.CLEAN)
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Pick
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[TaskConditionBody](sway_api/models/task_condition_body.py) \| [TaskConditionBodyDict](sway_api/models/task_condition_body.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;[Pick](sway_api/models/pick.py), [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[Pick](sway_api/models/pick.py)</code> -- agent pick + stability

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_publishers_onboard(body: ApiPublishersOnboardRequest | ApiPublishersOnboardRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Any, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.post_publishers_onboard(ApiPublishersOnboardRequest(host="some example string"))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.post_publishers_onboard(
    ApiPublishersOnboardRequest(host="some example string")
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiPublishersOnboardRequest](sway_api/models/api_publishers_onboard_request.py) \| [ApiPublishersOnboardRequestDict](sway_api/models/api_publishers_onboard_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;Any, [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>Any</code> -- referral session

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_vault_test(body: ApiVaultTestRequest | ApiVaultTestRequestDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Any, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.post_vault_test(ApiVaultTestRequest(vault_id="some example string"))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.post_vault_test(ApiVaultTestRequest(vault_id="some example string"))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[ApiVaultTestRequest](sway_api/models/api_vault_test_request.py) \| [ApiVaultTestRequestDict](sway_api/models/api_vault_test_request.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;Any, [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>Any</code> -- probe result

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_verdict(body: TaskConditionBody | TaskConditionBodyDict, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Verdict, RawError]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.post_verdict(TaskConditionBody(task="some example string", condition=Condition.CLEAN))
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Verdict
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

**Async**

```python
result = await async_client.with_raw_response.post_verdict(
    TaskConditionBody(task="some example string", condition=Condition.CLEAN)
)
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Verdict
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type RawError
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>[TaskConditionBody](sway_api/models/task_condition_body.py) \| [TaskConditionBodyDict](sway_api/models/task_condition_body.py)</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;[Verdict](sway_api/models/verdict.py), [RawError](sway_api/core/results.py)&#93;</code>

**On `Success`**: `payload` is <code>[Verdict](sway_api/models/verdict.py)</code> -- verdict + x-ray + one-sentence explanation

**On `Failure`**: `error` is <code>[RawError](sway_api/core/results.py)</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>def post_webhooks_paypal(body: Any, *, request_options: RequestOptionsOrDict | None = None) -> ApiResult[Any, PostWebhooksPaypalErrorBody]</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Send a `POST` request.

</dd>
</dl>

### Usage

<dl>
<dd>

**Sync**

```python
result = client.with_raw_response.post_webhooks_paypal({})
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type PostWebhooksPaypalErrorBody
```

**Async**

```python
result = await async_client.with_raw_response.post_webhooks_paypal({})
match result:
    case Success(payload=payload):
        ...  # TODO: Handle 'payload' of type Any
    case Failure(error=error):
        ...  # TODO: Handle 'error' of type PostWebhooksPaypalErrorBody
```

</dd>
</dl>

### Parameters

<dl>
<dd>

| Name | Type | Description |
| --- | --- | --- |
| <code>body</code> | <code>Any</code> | The request body. |
| <code>request_options</code> | <code>[RequestOptionsOrDict](sway_api/core/request_options.py) \| None</code> | Per-call overrides for this one request, such as a timeout, extra headers, or its retry count and statuses. |

</dd>
</dl>

### Response

<dl>
<dd>

**Returns**: <code>[ApiResult](sway_api/core/results.py)&#91;Any, [PostWebhooksPaypalErrorBody](sway_api/errors/post_webhooks_paypal_error.py)&#93;</code>

**On `Success`**: `payload` is <code>Any</code> -- received

**On `Failure`**: `error` is <code>[PostWebhooksPaypalErrorBody](sway_api/errors/post_webhooks_paypal_error.py)</code>

Mapped in first-match order -- an earlier row wins over a later range that also covers the status:

| Status | `error` is |
| --- | --- |
| 401 | <code>[RawError](sway_api/core/results.py)</code> |
| anything unmapped | <code>[RawError](sway_api/core/results.py)</code> |

</dd>
</dl>

</dd>
</dl>

</details>

