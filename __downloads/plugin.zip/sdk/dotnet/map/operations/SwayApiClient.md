<!-- Generated file — do not edit; regenerated with the SDK. -->

# SwayApiClient — operations

Accessor: `client` · Source: `src/SwayApi/SwayApiClient.cs` · 10 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### GetEvidence

- **Signature**: `GetEvidence(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `Evidence`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `Evidence` | `src/SwayApi/Models/Evidence.cs` |

### GetHealth

- **Signature**: `GetHealth(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `Health`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `Health` | `src/SwayApi/Models/Health.cs` |

### GetResults

- **Signature**: `GetResults(GetResultsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Query params (wire ← C#)**: `run` ← `Run`
- **Returns**: `object`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `GetResultsRequest` | `src/SwayApi/Requests/GetResultsRequest.cs` |

### GetTasks

- **Signature**: `GetTasks(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `TasksEnvelope`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `TasksEnvelope` | `src/SwayApi/Models/TasksEnvelope.cs` |

### PostPayoutsCredit

- **Signature**: `PostPayoutsCredit(PostPayoutsCreditRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `object`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `PostPayoutsCreditRequest` | `src/SwayApi/Requests/PostPayoutsCreditRequest.cs` |
| `ApiPayoutsCreditRequest` | `src/SwayApi/Models/ApiPayoutsCreditRequest.cs` |

### PostPick

- **Signature**: `PostPick(PostPickRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `Pick`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `PostPickRequest` | `src/SwayApi/Requests/PostPickRequest.cs` |
| `TaskConditionBody` | `src/SwayApi/Models/TaskConditionBody.cs` |
| `Pick` | `src/SwayApi/Models/Pick.cs` |

### PostPublishersOnboard

- **Signature**: `PostPublishersOnboard(PostPublishersOnboardRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `object`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `PostPublishersOnboardRequest` | `src/SwayApi/Requests/PostPublishersOnboardRequest.cs` |
| `ApiPublishersOnboardRequest` | `src/SwayApi/Models/ApiPublishersOnboardRequest.cs` |

### PostVaultTest

- **Signature**: `PostVaultTest(PostVaultTestRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `object`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `PostVaultTestRequest` | `src/SwayApi/Requests/PostVaultTestRequest.cs` |
| `ApiVaultTestRequest` | `src/SwayApi/Models/ApiVaultTestRequest.cs` |

### PostVerdict

- **Signature**: `PostVerdict(PostVerdictRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `Verdict`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `PostVerdictRequest` | `src/SwayApi/Requests/PostVerdictRequest.cs` |
| `TaskConditionBody` | `src/SwayApi/Models/TaskConditionBody.cs` |
| `Verdict` | `src/SwayApi/Models/Verdict.cs` |

### PostWebhooksPaypal

- **Signature**: `PostWebhooksPaypal(PostWebhooksPaypalRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `object`
- **Error**: `ApiException<PostWebhooksPaypalError>` — **Case A (typed)**
- **Error accessors**: `TryGetNoContent(out RawError)` [401] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `PostWebhooksPaypalRequest` | `src/SwayApi/Requests/PostWebhooksPaypalRequest.cs` |
| `PostWebhooksPaypalError` | `src/SwayApi/Errors/PostWebhooksPaypalError.cs` |

