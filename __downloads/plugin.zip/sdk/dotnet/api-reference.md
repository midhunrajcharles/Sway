# Reference

Every operation below is shown in its throwing form. On an error status it throws `ApiException<TError>` — the status code, headers, content type and the operation's error type, `RawError` (the raw body) when the spec declares none — and where an operation offers an `…AsResult` sibling, that sibling returns `ApiResult<TResponse, TError>` instead. A request that produces no usable response surfaces as `SdkConnectionException` or `SdkTimeoutException`, a body that does not match the documented response type as `ResponseDeserializationException`, and a required credential that is not configured, or one that cannot be applied, as `AuthSchemeException`; all of them derive from `SdkException` and name the failed call. See [README → Error Handling](README.md#error-handling).

> Source: [SwayApiClient](src/SwayApi/SwayApiClient.cs)

<details>
<summary><code>Task&lt;Evidence&gt; GetEvidence(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.GetEvidence();
    // TODO: Handle 'response' of type Evidence
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Evidence](src/SwayApi/Models/Evidence.cs)</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Health&gt; GetHealth(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.GetHealth();
    // TODO: Handle 'response' of type Health
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Health](src/SwayApi/Models/Health.cs)</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;object&gt; GetResults(GetResultsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.GetResults(new GetResultsRequest());
    // TODO: Handle 'response' of type object
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[GetResultsRequest](src/SwayApi/Requests/GetResultsRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;TasksEnvelope&gt; GetTasks(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.GetTasks();
    // TODO: Handle 'response' of type TasksEnvelope
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[TasksEnvelope](src/SwayApi/Models/TasksEnvelope.cs)</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;object&gt; PostPayoutsCredit(PostPayoutsCreditRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.PostPayoutsCredit(new PostPayoutsCreditRequest
    {
        Body = new ApiPayoutsCreditRequest { OrderId = "some example string" },
    });
    // TODO: Handle 'response' of type object
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PostPayoutsCreditRequest](src/SwayApi/Requests/PostPayoutsCreditRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Pick&gt; PostPick(PostPickRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.PostPick(new PostPickRequest
    {
        Body = new TaskConditionBody { Task = "some example string", Condition = Condition.Clean },
    });
    // TODO: Handle 'response' of type Pick
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PostPickRequest](src/SwayApi/Requests/PostPickRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Pick](src/SwayApi/Models/Pick.cs)</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;object&gt; PostPublishersOnboard(PostPublishersOnboardRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.PostPublishersOnboard(new PostPublishersOnboardRequest
    {
        Body = new ApiPublishersOnboardRequest { Host = "some example string" },
    });
    // TODO: Handle 'response' of type object
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PostPublishersOnboardRequest](src/SwayApi/Requests/PostPublishersOnboardRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;object&gt; PostVaultTest(PostVaultTestRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.PostVaultTest(new PostVaultTestRequest
    {
        Body = new ApiVaultTestRequest { VaultId = "some example string" },
    });
    // TODO: Handle 'response' of type object
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PostVaultTestRequest](src/SwayApi/Requests/PostVaultTestRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Verdict&gt; PostVerdict(PostVerdictRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.PostVerdict(new PostVerdictRequest
    {
        Body = new TaskConditionBody { Task = "some example string", Condition = Condition.Clean },
    });
    // TODO: Handle 'response' of type Verdict
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PostVerdictRequest](src/SwayApi/Requests/PostVerdictRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Verdict](src/SwayApi/Models/Verdict.cs)</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/SwayApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;object&gt; PostWebhooksPaypal(PostWebhooksPaypalRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.PostWebhooksPaypal(new PostWebhooksPaypalRequest { Body = body });
    // TODO: Handle 'response' of type object
}
catch (ApiException<PostWebhooksPaypalError> ex)
{
    if (ex.Error.TryGetNoContent(out var error))
    {
        // TODO: Handle 'error' of type RawError
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PostWebhooksPaypalRequest](src/SwayApi/Requests/PostWebhooksPaypalRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>object</code>

**OnError**: <code>[ApiException](src/SwayApi/Core/Exceptions/ApiException.cs)&lt;[PostWebhooksPaypalError](src/SwayApi/Errors/PostWebhooksPaypalError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

