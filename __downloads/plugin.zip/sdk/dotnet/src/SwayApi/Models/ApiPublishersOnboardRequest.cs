using System.Text.Json.Serialization;
using SwayApi.Core.Models;
using SwayApi.Core.Validation;
using SwayApi.Core.Validation.Attributes;

namespace SwayApi.Models;

public record ApiPublishersOnboardRequest
{
    [JsonPropertyName("host")]
    public required string Host { get; init; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("publisherEmail")]
    [Format(FormatKind.Email)]
    public string? PublisherEmail { get; init; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("returnUrl")]
    [Format(FormatKind.Uri)]
    public string? ReturnUrl { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
