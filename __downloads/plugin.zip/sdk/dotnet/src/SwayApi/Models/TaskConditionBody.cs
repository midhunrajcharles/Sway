using System.Text.Json.Serialization;
using SwayApi.Core.Models;
using SwayApi.Models.Enums;

namespace SwayApi.Models;

public record TaskConditionBody
{
    [JsonPropertyName("task")]
    public required string Task { get; init; }

    [JsonPropertyName("condition")]
    public required Condition Condition { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
