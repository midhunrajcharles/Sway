using System;
using System.Text.Json.Serialization;
using SwayApi.Core.Enum;

namespace SwayApi.Models.Enums;

[JsonConverter(typeof(StringEnumConverter<Condition>))]
public sealed record Condition : OpenStringEnum<Condition>
{
    private Condition(string value) : base(value)
    {
    }

    public static readonly Condition Clean = new("clean");

    public static readonly Condition HonestStrong = new("honest_strong");

    public static readonly Condition AttackHidden = new("attack_hidden");

    public static readonly Condition AttackRedundant = new("attack_redundant");

    public static readonly Condition DeceptiveVisible = new("deceptive_visible");

    public static readonly Condition CovertInstruction = new("covert_instruction");

    public static readonly Condition PriceSmear = new("price_smear");

    public static readonly Condition FakeReviews = new("fake_reviews");

    public TResult Match<TResult>(Func<TResult> onClean,
        Func<TResult> onHonestStrong,
        Func<TResult> onAttackHidden,
        Func<TResult> onAttackRedundant,
        Func<TResult> onDeceptiveVisible,
        Func<TResult> onCovertInstruction,
        Func<TResult> onPriceSmear,
        Func<TResult> onFakeReviews,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Clean => onClean(),
            _ when this == HonestStrong => onHonestStrong(),
            _ when this == AttackHidden => onAttackHidden(),
            _ when this == AttackRedundant => onAttackRedundant(),
            _ when this == DeceptiveVisible => onDeceptiveVisible(),
            _ when this == CovertInstruction => onCovertInstruction(),
            _ when this == PriceSmear => onPriceSmear(),
            _ when this == FakeReviews => onFakeReviews(),
            _ => otherwise(Value)
        };

    public void Match(Action onClean,
        Action onHonestStrong,
        Action onAttackHidden,
        Action onAttackRedundant,
        Action onDeceptiveVisible,
        Action onCovertInstruction,
        Action onPriceSmear,
        Action onFakeReviews,
        Action<string> otherwise)
    {
        if (this == Clean) onClean();
        else if (this == HonestStrong) onHonestStrong();
        else if (this == AttackHidden) onAttackHidden();
        else if (this == AttackRedundant) onAttackRedundant();
        else if (this == DeceptiveVisible) onDeceptiveVisible();
        else if (this == CovertInstruction) onCovertInstruction();
        else if (this == PriceSmear) onPriceSmear();
        else if (this == FakeReviews) onFakeReviews();
        else otherwise(Value);
    }
}
