using System;
using System.Text.Json.Serialization;
using SwayApi.Core.Enum;

namespace SwayApi.Models.Enums;

[JsonConverter(typeof(StringEnumConverter<Verdict1>))]
public sealed record Verdict1 : OpenStringEnum<Verdict1>
{
    private Verdict1(string value) : base(value)
    {
    }

    public static readonly Verdict1 Allow = new("allow");

    public static readonly Verdict1 Block = new("block");

    public TResult Match<TResult>(Func<TResult> onAllow, Func<TResult> onBlock, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Allow => onAllow(),
            _ when this == Block => onBlock(),
            _ => otherwise(Value)
        };

    public void Match(Action onAllow, Action onBlock, Action<string> otherwise)
    {
        if (this == Allow) onAllow();
        else if (this == Block) onBlock();
        else otherwise(Value);
    }
}
