using System.Text.Json.Serialization;
using SwayApi.Core.Models;

namespace SwayApi.Models;

public record ApiPayoutsCreditRequest
{
    [JsonPropertyName("orderId")]
    public required string OrderId { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
