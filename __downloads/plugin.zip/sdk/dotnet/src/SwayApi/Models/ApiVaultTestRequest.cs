using System.Text.Json.Serialization;
using SwayApi.Core.Models;

namespace SwayApi.Models;

public record ApiVaultTestRequest
{
    [JsonPropertyName("vaultId")]
    public required string VaultId { get; init; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("amount")]
    public double? Amount { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
