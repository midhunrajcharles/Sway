using SwayApi.Servers;

namespace SwayApi;

public class ServerOptions
{
    public DefaultOptions Default { get; set; } = new();
}
