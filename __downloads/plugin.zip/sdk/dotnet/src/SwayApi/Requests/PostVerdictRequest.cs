using SwayApi.Models;

namespace SwayApi.Requests;

/// <summary>
/// The inputs of the PostVerdict operation.
/// </summary>
public sealed record PostVerdictRequest
{
    public required TaskConditionBody Body { get; init; }
}
