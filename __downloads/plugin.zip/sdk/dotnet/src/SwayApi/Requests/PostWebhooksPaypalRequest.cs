namespace SwayApi.Requests;

/// <summary>
/// The inputs of the PostWebhooksPaypal operation.
/// </summary>
public sealed record PostWebhooksPaypalRequest
{
    public required object Body { get; init; }
}
