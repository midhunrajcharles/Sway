using SwayApi.Models;

namespace SwayApi.Requests;

/// <summary>
/// The inputs of the PostVaultTest operation.
/// </summary>
public sealed record PostVaultTestRequest
{
    public required ApiVaultTestRequest Body { get; init; }
}
