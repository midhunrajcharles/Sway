using SwayApi.Models;

namespace SwayApi.Requests;

/// <summary>
/// The inputs of the PostPayoutsCredit operation.
/// </summary>
public sealed record PostPayoutsCreditRequest
{
    public required ApiPayoutsCreditRequest Body { get; init; }
}
