namespace SwayApi.Requests;

/// <summary>
/// The inputs of the GetResults operation.
/// </summary>
public sealed record GetResultsRequest
{
    /// <summary>
    /// Specific results directory (defaults to the latest in results/).
    /// </summary>
    public string? Run { get; init; }
}
