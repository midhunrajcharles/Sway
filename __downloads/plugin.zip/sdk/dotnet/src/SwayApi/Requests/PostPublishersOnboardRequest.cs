using SwayApi.Models;

namespace SwayApi.Requests;

/// <summary>
/// The inputs of the PostPublishersOnboard operation.
/// </summary>
public sealed record PostPublishersOnboardRequest
{
    public required ApiPublishersOnboardRequest Body { get; init; }
}
