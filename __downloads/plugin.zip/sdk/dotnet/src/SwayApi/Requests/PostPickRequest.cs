using SwayApi.Models;

namespace SwayApi.Requests;

/// <summary>
/// The inputs of the PostPick operation.
/// </summary>
public sealed record PostPickRequest
{
    public required TaskConditionBody Body { get; init; }
}
