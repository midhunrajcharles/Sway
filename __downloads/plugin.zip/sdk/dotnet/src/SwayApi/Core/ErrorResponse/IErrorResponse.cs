using System.Threading;
using System.Threading.Tasks;
using SwayApi.Core.Models;

namespace SwayApi.Core.ErrorResponse;

internal interface IErrorResponse<TError>
{
    Task<TError> Map(ResponseContext context, CancellationToken cancellationToken);
}
