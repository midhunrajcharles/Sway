using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using SwayApi.Core.Hooks;
using SwayApi.Core.Models;

namespace SwayApi.Core;

public sealed record RequestOptions
{
    public LogLevel? LogLevel { get; init; }

    public IReadOnlyList<HeaderParam>? Headers { get; init; }

    public IReadOnlyList<SdkHook>? Hooks { get; init; }
}
