namespace SwayApi.Core.Models;

public readonly record struct HeaderParam(string Key, object? Value);
