using System.Threading.Tasks;
using SwayApi.Core.ErrorResponse;
using SwayApi.Core.Models;

namespace SwayApi.Errors;

public sealed class PostWebhooksPaypalError : ApiError
{
    private readonly Optional<RawError> _noContentValue;

    private PostWebhooksPaypalError(Optional<RawError> noContentValue, Optional<RawError> fallback) : base(fallback)
    {
        _noContentValue = noContentValue;
    }

    private static PostWebhooksPaypalError AsNoContent(RawError value) => new(Optional<RawError>.Some(value), default);

    private static PostWebhooksPaypalError AsFallback(RawError value) => new(default, Optional<RawError>.Some(value));

    public bool TryGetNoContent(out RawError value) => _noContentValue.TryGetValue(out value);

    private static Task<PostWebhooksPaypalError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            401 => response.RawBody().As(AsNoContent),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<PostWebhooksPaypalError> Response { get; } = new(Create);
}
