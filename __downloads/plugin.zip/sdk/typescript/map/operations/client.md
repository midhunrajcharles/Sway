<!-- Generated file — do not edit; regenerated with the SDK. -->

# SwayApiClient — ungrouped operations

Accessor: `client` (the client itself) · Source: `src/client.ts` · 10 operations · Request and error types: namespace `SwayApiClient`

Operations the spec leaves untagged are methods on the client rather than on a resource, so there is no accessor property to go through. The request type still lives in a namespace merged onto the exported class, so you write `SwayApiClient.GetResultsRequest`.

**Type sources**: every type an operation names, with the file that declares it and the schema value exported beside it. Import every name from `sway-api`; the `Source` path is where to **read** the shape, never what to import. `ApiError`, the runtime error family and the file vocabulary are excluded — see sdk-map.md.

### getEvidence

- **Signature**: `getEvidence(options?: RequestOptions): ApiPromise<Evidence, ApiError>`
- **Wire**: `GET /api/evidence`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `Evidence`
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

| Type | Schema value | Source |
| --- | --- | --- |
| `Evidence` | `evidenceSchema` | `src/models/evidence.ts` |

### getHealth

- **Signature**: `getHealth(options?: RequestOptions): ApiPromise<Health, ApiError>`
- **Wire**: `GET /api/health`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `Health`
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

| Type | Schema value | Source |
| --- | --- | --- |
| `Health` | `healthSchema` | `src/models/health.ts` |

### getResults

- **Signature**: `getResults(request?: SwayApiClient.GetResultsRequest, options?: RequestOptions): ApiPromise<Record<string, unknown>, ApiError>`
- **Wire**: `GET /api/results`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `Record<string, unknown>` — a bare `application/json` map; the success type *is* the map
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `SwayApiClient.GetResultsRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `run` | `query` | `string` | no |

### getTasks

- **Signature**: `getTasks(options?: RequestOptions): ApiPromise<TasksEnvelope, ApiError>`
- **Wire**: `GET /api/tasks`
- **Auth**: none — public; no credential is sent
- **Request body**: none — no `Content-Type` header is sent
- **Returns**: `TasksEnvelope`
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

| Type | Schema value | Source |
| --- | --- | --- |
| `TasksEnvelope` | `tasksEnvelopeSchema` | `src/models/tasks-envelope.ts` |

### postPayoutsCredit

- **Signature**: `postPayoutsCredit(request: SwayApiClient.PostPayoutsCreditRequest, options?: RequestOptions): ApiPromise<Record<string, unknown>, ApiError>`
- **Wire**: `POST /api/payouts/credit`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `Record<string, unknown>` — a bare `application/json` map; the success type *is* the map
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `SwayApiClient.PostPayoutsCreditRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiPayoutsCreditRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiPayoutsCreditRequest` | `apiPayoutsCreditRequestSchema` | `src/models/api-payouts-credit-request.ts` |

### postPick

- **Signature**: `postPick(request: SwayApiClient.PostPickRequest, options?: RequestOptions): ApiPromise<Pick, ApiError>`
- **Wire**: `POST /api/pick`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `Pick`
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `SwayApiClient.PostPickRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `TaskConditionBody` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `TaskConditionBody` | `taskConditionBodySchema` | `src/models/task-condition-body.ts` |
| `Pick` | `pickSchema` | `src/models/pick.ts` |

### postPublishersOnboard

- **Signature**: `postPublishersOnboard(request: SwayApiClient.PostPublishersOnboardRequest, options?: RequestOptions): ApiPromise<Record<string, unknown>, ApiError>`
- **Wire**: `POST /api/publishers/onboard`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `Record<string, unknown>` — a bare `application/json` map; the success type *is* the map
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `SwayApiClient.PostPublishersOnboardRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiPublishersOnboardRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiPublishersOnboardRequest` | `apiPublishersOnboardRequestSchema` | `src/models/api-publishers-onboard-request.ts` |

### postVaultTest

- **Signature**: `postVaultTest(request: SwayApiClient.PostVaultTestRequest, options?: RequestOptions): ApiPromise<Record<string, unknown>, ApiError>`
- **Wire**: `POST /api/vault/test`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `Record<string, unknown>` — a bare `application/json` map; the success type *is* the map
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `SwayApiClient.PostVaultTestRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `ApiVaultTestRequest` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `ApiVaultTestRequest` | `apiVaultTestRequestSchema` | `src/models/api-vault-test-request.ts` |

### postVerdict

- **Signature**: `postVerdict(request: SwayApiClient.PostVerdictRequest, options?: RequestOptions): ApiPromise<Verdict, ApiError>`
- **Wire**: `POST /api/verdict`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `Verdict`
- **Error**: `SwayApiError` with `kind: "api"` — untyped, `payload.kind` always `"undeclared"`

**Fields** — `SwayApiClient.PostVerdictRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `TaskConditionBody` | yes |

| Type | Schema value | Source |
| --- | --- | --- |
| `TaskConditionBody` | `taskConditionBodySchema` | `src/models/task-condition-body.ts` |
| `Verdict` | `verdictSchema` | `src/models/verdict.ts` |

### postWebhooksPaypal

- **Signature**: `postWebhooksPaypal(request: SwayApiClient.PostWebhooksPaypalRequest, options?: RequestOptions): ApiPromise<Record<string, unknown>, SwayApiClient.PostWebhooksPaypalError>`
- **Wire**: `POST /api/webhooks/paypal`
- **Auth**: none — public; no credential is sent
- **Request body**: `application/json` — the `body` field, a bare top-level JSON map with no fixed keys
- **SDK-sent**: `header Idempotency-Key` (minted per call)
- **Returns**: `Record<string, unknown>` — a bare `application/json` map; the success type *is* the map
- **Error**: `SwayApiError` with `kind: "api"`, an instance of `SwayApiClient.PostWebhooksPaypalError` — **typed arms**, narrowed on `err.payload.kind`
- **Error arms**: `"error401"` [401] no body · `"undeclared"` [any other] `rawBody: ArrayBuffer`

**Fields** — `SwayApiClient.PostWebhooksPaypalRequest` (1):

| Field | Channel | Type | Req |
| --- | --- | --- | --- |
| `body` | `body` | `Record<string, unknown>` | yes |

