import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type Product = {
  id?: string;
  name?: string;
  price?: number;
  seller?: string;
};

export const productSchema: Schema<Product> = s.object<Product>({
  id: s.optional(s.string()),
  name: s.optional(s.string()),
  price: s.optional(s.float64()),
  seller: s.optional(s.string()),
});
