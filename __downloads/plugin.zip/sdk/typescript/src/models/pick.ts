import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import { pageSchema, type Page } from "./page.js";
import { productSchema, type Product } from "./product.js";

export type Pick = {
  task?: Record<string, unknown>;
  products?: Product[];
  condition?: string;
  chosen?: string;
  stability?: number;
  pages?: Page[];
  target?: string | null;
};

export const pickSchema: Schema<Pick> = s.object<Pick>({
  task: s.optional(s.record(s.string(), s.unknown())),
  products: s.optional(s.array(s.lazy(() => productSchema))),
  condition: s.optional(s.string()),
  chosen: s.optional(s.string()),
  stability: s.optional(s.float64()),
  pages: s.optional(s.array(s.lazy(() => pageSchema))),
  target: s.optionalNullable(s.string()),
});
