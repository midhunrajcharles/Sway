import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import { conditionSchema, type Condition } from "./condition.js";

export type TaskConditionBody = {
  task: string;
  condition: Condition;
};

export const taskConditionBodySchema: Schema<TaskConditionBody> = s.object<TaskConditionBody>({
  task: s.string(),
  condition: conditionSchema,
});
