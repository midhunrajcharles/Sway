import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type Evidence = {
  mainRun?: string;
  main?: Record<string, unknown>[];
  subtle?: Record<string, unknown>[];
  model?: string;
  k?: number;
};

export const evidenceSchema: Schema<Evidence> = s.object<Evidence>({
  mainRun: s.optional(s.string()),
  main: s.optional(s.array(s.record(s.string(), s.unknown()))),
  subtle: s.optional(s.array(s.record(s.string(), s.unknown()))),
  model: s.optional(s.string()),
  k: s.optional(s.int()),
  _keysMap: {
    mainRun: "main_run",
  },
});
