import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type ApiPublishersOnboardRequest = {
  host: string;
  publisherEmail?: string;
  returnUrl?: string;
};

export const apiPublishersOnboardRequestSchema: Schema<ApiPublishersOnboardRequest> =
  s.object<ApiPublishersOnboardRequest>({
    host: s.string(),
    publisherEmail: s.optional(s.string()),
    returnUrl: s.optional(s.string()),
  });
