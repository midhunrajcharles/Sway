import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type ApiVaultTestRequest = {
  vaultId: string;
  amount?: number;
};

export const apiVaultTestRequestSchema: Schema<ApiVaultTestRequest> = s.object<ApiVaultTestRequest>({
  vaultId: s.string(),
  amount: s.optional(s.float64()),
});
