import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type Health = {
  ok: boolean;
  backend?: string;
  model?: string;
  k?: number;
};

export const healthSchema: Schema<Health> = s.object<Health>({
  ok: s.boolean(),
  backend: s.optional(s.string()),
  model: s.optional(s.string()),
  k: s.optional(s.int()),
});
