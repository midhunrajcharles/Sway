import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type ApiPayoutsCreditRequest = {
  orderId: string;
};

export const apiPayoutsCreditRequestSchema: Schema<ApiPayoutsCreditRequest> =
  s.object<ApiPayoutsCreditRequest>({
    orderId: s.string(),
  });
