import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type Page = {
  id?: string;
  url?: string;
};

export const pageSchema: Schema<Page> = s.object<Page>({
  id: s.optional(s.string()),
  url: s.optional(s.string()),
});
