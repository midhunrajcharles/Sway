import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import { verdict1Schema, type Verdict1 } from "./verdict1.js";

export type Verdict = {
  verdict?: Verdict1;
  sentence?: string;
  chosen?: string;
  stability?: number;
  xray?: Record<string, unknown>[];
  decider?: string | null;
  payoutEligible?: boolean;
};

export const verdictSchema: Schema<Verdict> = s.object<Verdict>({
  verdict: s.optional(s.lazy(() => verdict1Schema)),
  sentence: s.optional(s.string()),
  chosen: s.optional(s.string()),
  stability: s.optional(s.float64()),
  xray: s.optional(s.array(s.record(s.string(), s.unknown()))),
  decider: s.optionalNullable(s.string()),
  payoutEligible: s.optional(s.boolean()),
  _keysMap: {
    payoutEligible: "payout_eligible",
  },
});
