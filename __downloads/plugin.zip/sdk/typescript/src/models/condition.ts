import * as s from "../core/validation/index.js";
import type { EnumSchema } from "../core/validation/schema.js";

export const Condition = {
  Clean: "clean",
  HonestStrong: "honest_strong",
  AttackHidden: "attack_hidden",
  AttackRedundant: "attack_redundant",
  DeceptiveVisible: "deceptive_visible",
  CovertInstruction: "covert_instruction",
  PriceSmear: "price_smear",
  FakeReviews: "fake_reviews",
} as const;
export type Condition = (typeof Condition)[keyof typeof Condition] | (string & {});

export const conditionSchema: EnumSchema<Condition> = s.enumOf<Condition>(Condition);
