import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

export type TasksEnvelope = {
  conditions?: string[];
  tasks?: Record<string, unknown>[];
};

export const tasksEnvelopeSchema: Schema<TasksEnvelope> = s.object<TasksEnvelope>({
  conditions: s.optional(s.array(s.string())),
  tasks: s.optional(s.array(s.record(s.string(), s.unknown()))),
});
