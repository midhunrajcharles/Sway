import type { ClientOptions } from "./client-options.js";
import { ApiError, type Declared, type Undeclared } from "./core/api-error.js";
import type { ApiPromise } from "./core/api-promise.js";
import type { RequestOptions } from "./core/api-request.js";
import { noneAuth } from "./core/auth/schemes.js";
import { buildCoreClientOptions } from "./core/client-options.js";
import { RawClient } from "./core/raw-client.js";
import type { ErrorDecoders } from "./core/response-decoder.js";
import * as host from "./core/runtime-environment.js";
import { uuid } from "./core/uuid.js";
import * as s from "./core/validation/index.js";
import {
  apiPayoutsCreditRequestSchema,
  type ApiPayoutsCreditRequest,
} from "./models/api-payouts-credit-request.js";
import {
  apiPublishersOnboardRequestSchema,
  type ApiPublishersOnboardRequest,
} from "./models/api-publishers-onboard-request.js";
import { apiVaultTestRequestSchema, type ApiVaultTestRequest } from "./models/api-vault-test-request.js";
import { evidenceSchema, type Evidence } from "./models/evidence.js";
import { healthSchema, type Health } from "./models/health.js";
import { pickSchema, type Pick } from "./models/pick.js";
import { taskConditionBodySchema, type TaskConditionBody } from "./models/task-condition-body.js";
import { tasksEnvelopeSchema, type TasksEnvelope } from "./models/tasks-envelope.js";
import { verdictSchema, type Verdict } from "./models/verdict.js";
import { buildServers, type Servers } from "./servers.js";

/**
 * Sway runs the agent's shopping decision with each page it read ablated, scores each page's causal
 * weight, and asks a second key — the Channel3 catalog — whether the deciding page tells the truth.
 * The result is a pre-capture verdict ('allow' or 'block') and, when honest, a Payout destination.
 */
export class SwayApiClient {
  readonly #rawClient: RawClient;
  readonly #servers: Servers;

  constructor(options: ClientOptions = {}) {
    this.#rawClient = new RawClient({
      ...buildCoreClientOptions(options, "SWAY_API_CLIENT_LOG"),
      defaultHeaders: [
        { name: "User-Agent", value: "SwayApiClient/0.2.0 TypeScript", schema: s.string() },
        { name: "X-APIMatic-Lang", value: "TypeScript", schema: s.string() },
        { name: "X-APIMatic-Package-Version", value: "0.2.0", schema: s.string() },
        { name: "X-APIMatic-Gen-Version", value: "4.0.0", schema: s.string() },
        { name: "X-APIMatic-OS", value: host.operatingSystem(), schema: s.optional(s.string()) },
        { name: "X-APIMatic-Runtime", value: host.runtimeDescription(), schema: s.optional(s.string()) },
      ],
      defaultQuery: [],
      defaultPathParams: [],
    });

    this.#servers = buildServers(options);
  }

  /**
   * Headline numbers for the /evidence page
   *
   * @returns evidence payload
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getEvidence(options?: RequestOptions): ApiPromise<Evidence, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/evidence"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: evidenceSchema },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Service health
   *
   * @returns ok
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getHealth(options?: RequestOptions): ApiPromise<Health, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/health"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: healthSchema },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Latest benchmark rows for the AG Grid views
   *
   * @returns results rows + xray
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getResults(
    request: SwayApiClient.GetResultsRequest = {},
    options?: RequestOptions,
  ): ApiPromise<Record<string, unknown>, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/results"),
        auth: noneAuth,
        pathParams: [],
        query: [{ name: "run", value: request.run, schema: s.optional(s.string()) }],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: s.record(s.string(), s.unknown()) },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Benchmark tasks with real Channel3 products
   *
   * @returns tasks + conditions
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  getTasks(options?: RequestOptions): ApiPromise<TasksEnvelope, ApiError> {
    return this.#rawClient.execute(
      {
        method: "GET",
        urlTemplate: this.#servers.default("/api/tasks"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [],
        body: { kind: "empty" },
      },
      {
        success: { kind: "json", schema: tasksEnvelopeSchema },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Pay the publisher that causally decided an honest buy
   *
   * @returns payout result
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  postPayoutsCredit(
    request: SwayApiClient.PostPayoutsCreditRequest,
    options?: RequestOptions,
  ): ApiPromise<Record<string, unknown>, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/payouts/credit"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiPayoutsCreditRequestSchema },
      },
      {
        success: { kind: "json", schema: s.record(s.string(), s.unknown()) },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * What the shopping agent would buy (baseline, no Sway check)
   *
   * @returns agent pick + stability
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  postPick(request: SwayApiClient.PostPickRequest, options?: RequestOptions): ApiPromise<Pick, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/pick"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: taskConditionBodySchema },
      },
      {
        success: { kind: "json", schema: pickSchema },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Create a PayPal Partner Referrals session for a publisher
   *
   * @returns referral session
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  postPublishersOnboard(
    request: SwayApiClient.PostPublishersOnboardRequest,
    options?: RequestOptions,
  ): ApiPromise<Record<string, unknown>, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/publishers/onboard"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiPublishersOnboardRequestSchema },
      },
      {
        success: { kind: "json", schema: s.record(s.string(), s.unknown()) },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Sandbox probe: AUTHORIZE + payment_source.paypal.vault_id
   *
   * @returns probe result
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  postVaultTest(
    request: SwayApiClient.PostVaultTestRequest,
    options?: RequestOptions,
  ): ApiPromise<Record<string, unknown>, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/vault/test"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: apiVaultTestRequestSchema },
      },
      {
        success: { kind: "json", schema: s.record(s.string(), s.unknown()) },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * Full Sway verdict before PayPal captures
   *
   * @returns verdict + x-ray + one-sentence explanation
   *
   * @throws {@link ApiError} when the API answers with an error status
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  postVerdict(
    request: SwayApiClient.PostVerdictRequest,
    options?: RequestOptions,
  ): ApiPromise<Verdict, ApiError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/verdict"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: taskConditionBodySchema },
      },
      {
        success: { kind: "json", schema: verdictSchema },
        errorFactory: ApiError,
      },
      options,
    );
  }

  /**
   * PayPal webhook ingest (signature-verified, idempotent by event id)
   *
   * @returns received
   *
   * @throws {@link SwayApiClient.PostWebhooksPaypalError} when the API answers with an error status
   * — narrow on `err.payload.kind`
   *
   * @throws {@link SwayApiError} when no usable response was produced: a connection failure, a
   * timeout, a body that would not decode, a value that would not encode, or a credential that
   * could not be obtained
   */
  postWebhooksPaypal(
    request: SwayApiClient.PostWebhooksPaypalRequest,
    options?: RequestOptions,
  ): ApiPromise<Record<string, unknown>, SwayApiClient.PostWebhooksPaypalError> {
    return this.#rawClient.execute(
      {
        method: "POST",
        urlTemplate: this.#servers.default("/api/webhooks/paypal"),
        auth: noneAuth,
        pathParams: [],
        query: [],
        headers: [{ name: "Idempotency-Key", value: uuid(), schema: s.string() }],
        body: { kind: "json", value: request.body, schema: s.record(s.string(), s.unknown()) },
      },
      {
        success: { kind: "json", schema: s.record(s.string(), s.unknown()) },
        errorFactory: SwayApiClient.PostWebhooksPaypalError,
      },
      options,
    );
  }
}

export namespace SwayApiClient {
  export type GetResultsRequest = {
    /** Specific results directory (defaults to the latest in results/). */
    run?: string;
  };

  export type PostPayoutsCreditRequest = {
    body: ApiPayoutsCreditRequest;
  };

  export type PostPickRequest = {
    body: TaskConditionBody;
  };

  export type PostPublishersOnboardRequest = {
    body: ApiPublishersOnboardRequest;
  };

  export type PostVaultTestRequest = {
    body: ApiVaultTestRequest;
  };

  export type PostVerdictRequest = {
    body: TaskConditionBody;
  };

  export type PostWebhooksPaypalRequest = {
    body: Record<string, unknown>;
  };

  export class PostWebhooksPaypalError extends ApiError {
    declare readonly payload: Declared<"error401", undefined> | Undeclared;

    static readonly errors: ErrorDecoders<PostWebhooksPaypalError> = [
      { on: 401, kind: "error401", decode: { kind: "empty" } },
    ];
  }
}
